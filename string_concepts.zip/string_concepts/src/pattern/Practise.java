package pattern;

public class Practise {

}
