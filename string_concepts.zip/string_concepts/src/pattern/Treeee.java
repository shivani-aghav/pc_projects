package pattern;

public class Treeee {

	
	public static void main(String[] args) {
		
		
	}
}
