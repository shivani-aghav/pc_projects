package string_concepts.mystring1;

public class StringBufferBuilder {
	public static void main(String[] args) {
		StringBuffer sb = new StringBuffer("kkk");
		StringBufferBuilder s = new StringBufferBuilder();
		System.out.println(s.hashCode());
//		sb.insert(0, "rutu");
//		sb.insert(1, "emily");
//		sb.insert(2, "juka");
//		System.out.println(sb);
//		System.out.println("----------------");
//
//		StringBuffer sb1 = new StringBuffer("11111");
//		System.out.println(sb1.insert(3, false).insert(5, 3.3).insert(7, "One"));
//		System.out.println("----------------");
//
//		System.out.println(7.7 + 3.3 + "Java" + 3.3 + 7.7);
//		System.out.println("----------------");

//		System.out.println("JAVAJ2EE".substring(2, 5).substring(1).charAt(2));// AJ out of which charAt(2) will give
		                                         							  // outofboundExcption
	
		
	}
}
