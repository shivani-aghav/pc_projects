package string_concepts.mystring1;

public class EvenUpperCase {

	public static void main(String[] args) {
		String s = "john";
//		Stream.of(s.split("")).filter(t -> s.length() % 2 == 0).map(t -> t.toUpperCase() + "")
//				.forEach(System.out::println);

		float f = 44.4f;
        long b=(long) f;
	}
}
